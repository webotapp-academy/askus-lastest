<?php
require_once __DIR__ . '/../config.php';

try {
    $pdo = getDBConnection();

    $categoryId = $_GET['category_id'] ?? null;
    $vendorId = $_GET['vendor_id'] ?? null;
    $featured = $_GET['featured'] ?? null;
    $search = $_GET['search'] ?? null;

    $where = "s.status = 'active' AND s.deleted_at IS NULL AND v.status = 'approved' AND v.deleted_at IS NULL";
    $params = [];

    if ($categoryId) {
        $where .= " AND s.category_id = ?";
        $params[] = $categoryId;
    }

    if ($vendorId) {
        $where .= " AND s.vendor_id = ?";
        $params[] = $vendorId;
    }

    if ($featured) {
        $where .= " AND s.is_featured = 1";
    }

    if ($search) {
        $where .= " AND (s.name LIKE ? OR s.description LIKE ?)";
        $params[] = "%$search%";
        $params[] = "%$search%";
    }

    $stmt = $pdo->prepare("
        SELECT s.*, v.store_name as vendor_name, c.name as category_name
        FROM services s
        JOIN vendors v ON s.vendor_id = v.id
        LEFT JOIN categories c ON s.category_id = c.id
        WHERE $where
        ORDER BY s.is_featured DESC, s.created_at DESC
        LIMIT 50
    ");
    $stmt->execute($params);
    $services = $stmt->fetchAll();

    foreach ($services as &$service) {
        if (!isset($service['price']) && isset($service['min_price'])) {
            $service['price'] = $service['min_price'];
        }
        $service['images'] = [];
        $service['thumbnail'] = null;
    }

    jsonResponse([
        'success' => true,
        'services' => $services
    ]);

} catch (Exception $e) {
    error_log("Services list error: " . $e->getMessage());
    jsonResponse(['success' => true, 'services' => []]);
}
