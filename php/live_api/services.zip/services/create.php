<?php
require_once __DIR__ . '/../config.php';

$vendor = requireVendor();

$input = getInput();
$name = trim($input['name'] ?? '');
$description = trim($input['description'] ?? '');
$categoryId = intval($input['category_id'] ?? 0);
$price = floatval($input['price'] ?? 0);
$duration = trim($input['duration'] ?? '');

if (empty($name) || empty($description) || !$categoryId || $price <= 0) {
    jsonResponse(['success' => false, 'message' => 'Required fields missing'], 400);
}

$pdo = getDBConnection();

$uuid = generateUUID();
$slug = createSlug($name);

$stmt = $pdo->prepare("INSERT INTO services (uuid, vendor_id, category_id, name, slug, description, price, duration, status, created_at, updated_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?, 'active', NOW(), NOW())");
$stmt->execute([$uuid, $vendor['id'], $categoryId, $name, $slug, $description, $price, $duration ?: null]);
$serviceId = $pdo->lastInsertId();

if (!empty($_FILES['images'])) {
    $files = is_array($_FILES['images']['name']) ? $_FILES['images'] : [$_FILES['images']];
    $count = is_array($_FILES['images']['name']) ? count($_FILES['images']['name']) : 1;
    
    for ($i = 0; $i < $count; $i++) {
        if (is_array($_FILES['images']['name'])) {
            $file = [
                'name' => $_FILES['images']['name'][$i],
                'tmp_name' => $_FILES['images']['tmp_name'][$i],
                'error' => $_FILES['images']['error'][$i],
            ];
        } else {
            $file = $_FILES['images'];
        }
        
        if ($file['error'] === 0) {
            $imageUrl = uploadFile($file, 'services');
            if ($imageUrl) {
                $imgUuid = generateUUID();
                $pdo->prepare("INSERT INTO service_images (uuid, service_id, image_url, sort_order) VALUES (?, ?, ?, ?)")
                    ->execute([$imgUuid, $serviceId, $imageUrl, $i]);
            }
        }
    }
}

jsonResponse([
    'success' => true,
    'id' => $serviceId,
    'message' => 'Service created successfully'
]);
