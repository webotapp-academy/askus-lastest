<?php
require_once __DIR__ . '/../config.php';

$vendor = requireVendor();

$id = intval($_GET['id'] ?? 0);
if (!$id) {
    jsonResponse(['success' => false, 'message' => 'Service ID required'], 400);
}

$pdo = getDBConnection();

$stmt = $pdo->prepare("SELECT * FROM services WHERE id = ? AND vendor_id = ? AND deleted_at IS NULL");
$stmt->execute([$id, $vendor['id']]);
$service = $stmt->fetch();

if (!$service) {
    jsonResponse(['success' => false, 'message' => 'Service not found'], 404);
}

$input = getInput();
$updates = [];
$params = [];

$fields = ['name', 'description', 'category_id', 'price', 'duration', 'status'];

foreach ($fields as $field) {
    if (isset($input[$field])) {
        $updates[] = "$field = ?";
        $params[] = $input[$field];
    }
}

if (empty($updates)) {
    jsonResponse(['success' => false, 'message' => 'No fields to update'], 400);
}

$updates[] = "updated_at = NOW()";
$params[] = $id;

$sql = "UPDATE services SET " . implode(", ", $updates) . " WHERE id = ?";
$stmt = $pdo->prepare($sql);
$stmt->execute($params);

jsonResponse([
    'success' => true,
    'message' => 'Service updated successfully'
]);
