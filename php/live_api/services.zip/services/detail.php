<?php
require_once __DIR__ . '/../config.php';

$id = intval($_GET['id'] ?? 0);
if (!$id) {
    jsonResponse(['success' => false, 'message' => 'Service ID required'], 400);
}

$pdo = getDBConnection();

$stmt = $pdo->prepare("
    SELECT s.*, v.store_name as vendor_name, v.rating as vendor_rating, v.city as vendor_city,
           c.name as category_name
    FROM services s
    JOIN vendors v ON s.vendor_id = v.id
    LEFT JOIN categories c ON s.category_id = c.id
    WHERE s.id = ? AND s.deleted_at IS NULL
");
$stmt->execute([$id]);
$service = $stmt->fetch();

if (!$service) {
    jsonResponse(['success' => false, 'message' => 'Service not found'], 404);
}

$imgStmt = $pdo->prepare("SELECT image_url FROM service_images WHERE service_id = ? ORDER BY sort_order");
$imgStmt->execute([$id]);
$service['images'] = array_column($imgStmt->fetchAll(), 'image_url');
$service['thumbnail'] = $service['images'][0] ?? null;

jsonResponse([
    'success' => true,
    'service' => $service
]);
